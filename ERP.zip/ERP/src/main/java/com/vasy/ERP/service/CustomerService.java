package com.vasy.ERP.service;

import java.util.List;

import javax.swing.text.DefaultEditorKit.CutAction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vasy.ERP.pojo.Customer;
import com.vasy.ERP.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	public Customer addCustomer(Customer customer) {
		Customer customer2 = customerRepository.save(customer);
		return customer2;
	}

	public Customer updateCustomer(Customer customer) {

		Customer customer2 = customerRepository.save(customer);
		return customer2;
	}

	public void deleteCustomer(long customerid) {
		customerRepository.deleteById(customerid);
	}

	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

}
